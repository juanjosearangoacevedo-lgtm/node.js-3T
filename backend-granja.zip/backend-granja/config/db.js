const mongoose = require('mongoose');

const conectarDB = async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI); // Conecta usando la URI del .env [cite: 102, 181, 185]
    console.log('¡Conectado a la Granja en MongoDB!');
  } catch (error) {
    console.error('Error de conexión:', error.message);
    process.exit(1); // Detiene la app si falla la conexión (Fail Fast) [cite: 104, 109, 182, 187]
  }
};

module.exports = conectarDB;