const mongoose = require('mongoose');

// Definimos la estructura de nuestra colección "animales"
const AnimalSchema = mongoose.Schema({
    nombre: {
        type: String,
        required: true, // Campo obligatorio [cite: 30]
        trim: true
    },
    especie: {
        type: String,
        required: true,
        trim: true
    },
    edad: {
        type: Number,
        required: true
    },
    DMA:{
        type: String,
        required:true
    },
    saludable: {
        type: Boolean,
        default: true // Si no se especifica, asumimos que está sano
    },
    fechaRegistro: {
        type: Date,
        default: Date.now // Se asigna automáticamente la fecha actual
    }
});

// Exportamos el modelo para usarlo en los controladores [cite: 52, 164]
module.exports = mongoose.model('Animal', AnimalSchema);