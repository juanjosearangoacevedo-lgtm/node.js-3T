const express = require('express');
const conectarDB = require('./config/db');
require('dotenv').config(); // Carga las variables del .env [cite: 79, 156]

// 1. Crear el servidor
const app = express();

// 2. Conectar a la Base de Datos
conectarDB(); 
// [cite: 181]

// 3. Middlewares (Permite recibir JSON en las peticiones) [cite: 64]
app.use(express.json());

// 4. Definir las rutas de la Granja [cite: 55, 166]
app.use('/api/animales', require('./routes/animal.routes.js'));

// 5. Arrancar el servidor
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`El servidor de la granja está corriendo en el puerto ${PORT}`);
});