const Animal = require('../models/Animal'); // Importamos el modelo que acabamos de crear

// Acción: Crear un nuevo animal (POST) [cite: 16]
exports.crearAnimal = async (req, res) => {
    try {
        const nuevoAnimal = new Animal(req.body); // Creamos el objeto con los datos del cuerpo de la petición [cite: 72]
        await nuevoAnimal.save(); // Lo guardamos en MongoDB [cite: 75]
        res.status(201).json(nuevoAnimal);
    } catch (error) {
        console.log(error);
        res.status(500).send('Hubo un error al intentar guardar el animal');
    }
};

// Acción: Obtener todos los animales (GET) [cite: 16]
exports.obtenerAnimales = async (req, res) => {
    try {
        const animales = await Animal.find(); // Busca todos los documentos en la colección [cite: 16, 128]
        res.json(animales);
    } catch (error) {
        console.log(error);
        res.status(500).send('Hubo un error al consultar los datos');
    }
};

// Acción: Obtener UN SOLO animal por ID (GET)
exports.obtenerAnimal = async (req, res) => {
    try {
        let animal = await Animal.findById(req.params.id);
        if (!animal) {
            return res.status(404).json({ msg: 'Animal no encontrado' });
        }
        res.json(animal);
    } catch (error) {
        console.log(error);
        res.status(500).send('Error al consultar el animal');
    }
};

// Acción: Actualizar un animal (PUT)
exports.actualizarAnimal = async (req, res) => {
    try {
        const { nombre, especie, edad, saludable } = req.body;
        let animal = await Animal.findById(req.params.id);

        if (!animal) {
            return res.status(404).json({ msg: 'El animal no existe' });
        }

        // Actualizamos los campos
        animal.nombre = nombre;
        animal.especie = especie;
        animal.edad = edad;
        animal.saludable = saludable;

        animal = await Animal.findByIdAndUpdate({ _id: req.params.id }, animal, { new: true });
        res.json(animal);

    } catch (error) {
        console.log(error);
        res.status(500).send('Error al actualizar el animal');
    }
};

// Acción: Eliminar un animal (DELETE)
exports.eliminarAnimal = async (req, res) => {
    try {
        let animal = await Animal.findById(req.params.id);
        if (!animal) {
            return res.status(404).json({ msg: 'El animal no existe' });
        }

        await Animal.findOneAndDelete({ _id: req.params.id });
        res.json({ msg: 'Animal eliminado correctamente de la granja' });

    } catch (error) {
        console.log(error);
        res.status(500).send('Error al eliminar el animal');
    }
};