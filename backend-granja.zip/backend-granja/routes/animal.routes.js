const express = require('express');
const router = express.Router(); 
const animalController = require('../controllers/animal.controller');

// Ruta base: /api/animales

// 1. Crear un animal
router.post('/', animalController.crearAnimal); 

// 2. Leer todos los animales
router.get('/', animalController.obtenerAnimales); 

// --- Rutas con ID específico ---

// 3. Leer UN solo animal (ESTA ES LA QUE TE FALTA)
router.get('/:id', animalController.obtenerAnimal);

// 4. Actualizar un animal
router.put('/:id', animalController.actualizarAnimal);

// 5. Eliminar un animal
router.delete('/:id', animalController.eliminarAnimal);

module.exports = router;