const ventas = [
  { vendedor: "Ana", monto: 500000 },
  { vendedor: "Luis", monto: 700000 },
  { vendedor: "Ana", monto: 300000 }
];


function procesarVentas(ventas){
  return new Promise((resolve, reject) => {

    if(!Array.isArray(ventas)){
      reject("Error: las ventas deben estar en un arreglo");
      return;
    }

    let resumen = {};
    let ventasProcesadas = [];

    ventas.forEach(v => {

      let comision = v.monto * 0.05;

      ventasProcesadas.push({
        vendedor: v.vendedor,
        monto: v.monto,
        comision: comision
      });

      if(!resumen[v.vendedor]){
        resumen[v.vendedor] = 0;
      }

      resumen[v.vendedor] += v.monto;

    });

    let vendedorTop = null;
    let mayorVenta = 0;

    for(let vendedor in resumen){
      if(resumen[vendedor] > mayorVenta){
        mayorVenta = resumen[vendedor];
        vendedorTop = vendedor;
      }
    }

    let reporte = {
      ventasProcesadas: ventasProcesadas,
      resumen: resumen,
      vendedorTop: vendedorTop
    };

    resolve(reporte);

  });
}


procesarVentas(ventas)
.then(resultado => {
  console.log("Reporte final:", resultado);
})
.catch(error => {
  console.error(error);
});
