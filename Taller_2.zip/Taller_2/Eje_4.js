const carritos = [
  { cliente: "Ana", ciudad: "Medellín", productos: [{ precio: 50000, cantidad: 2 }] },
  { cliente: "Luis", ciudad: "Bogotá", productos: [] }
];

function procesarCarritos(carritos){
  return new Promise((resolve, reject) => {

    if(!Array.isArray(carritos)){
      reject("Error: los carritos deben estar en un arreglo");
      return;
    }

    let ventasOK = [];
    let ventasError = [];
    let totalVentas = 0;

    carritos.forEach(carro => {

      if(!carro.productos || carro.productos.length === 0){
        ventasError.push({
          cliente: carro.cliente,
          error: "Carrito sin productos"
        });
      }else{

        let subtotal = 0;

        carro.productos.forEach(p => {
          subtotal += p.precio * p.cantidad;
        });

        let envio = 0;

        if(carro.ciudad === "Medellín"){
          envio = 10000;
        }else{
          envio = 20000;
        }

        let descuento = 0;

        if(subtotal > 100000){
          descuento = subtotal * 0.05;
        }

        let total = subtotal + envio - descuento;

        totalVentas += total;

        ventasOK.push({
          cliente: carro.cliente,
          subtotal: subtotal,
          envio: envio,
          descuento: descuento,
          total: total
        });
      }

    });

    let reporte = {
      ventasOK: ventasOK,
      ventasError: ventasError,
      totalVentas: totalVentas
    };

    resolve(reporte);

  });
}


procesarCarritos(carritos)
.then(resultado => {
  console.log("Reporte final:", resultado);
})
.catch(error => {
  console.error(error);
});
