const productos = [
  { nombre: "Laptop", stockActual: 3, stockMinimo: 5, precio: 2000000 },
  { nombre: "Mouse", stockActual: 20, stockMinimo: 10, precio: 50000 }
];


function procesarInventario(productos){
  return new Promise((resolve, reject) => {

    if(!Array.isArray(productos)){
      reject("Error: los productos deben estar en un arreglo");
      return;
    }

    let listaReposicion = [];
    let costoTotalReposicion = 0;

    productos.forEach(p => {

      if(p.stockActual < p.stockMinimo){

        let cantidadAReponer = p.stockMinimo - p.stockActual;

        let costoReposicion = cantidadAReponer * p.precio;

        costoTotalReposicion += costoReposicion;

        listaReposicion.push({
          nombre: p.nombre,
          cantidadAReponer: cantidadAReponer,
          costoReposicion: costoReposicion
        });

      }

    });

    let reporte = {
      listaReposicion: listaReposicion,
      costoTotalReposicion: costoTotalReposicion
    };

    resolve(reporte);

  });
}


procesarInventario(productos)
.then(resultado => {
  console.log("Reporte final:", resultado);
})
.catch(error => {
  console.error(error);
});
