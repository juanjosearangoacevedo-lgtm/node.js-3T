const prestamos = [
  { cliente: "Ana", monto: 10000000, tasa: 0.02, plazo: 12 },
  { cliente: "Luis", monto: 0, tasa: 0.03, plazo: 24 }
];


function procesarPrestamos(prestamos){
  return new Promise((resolve, reject) => {

    if(!Array.isArray(prestamos)){
      reject("Error: los préstamos deben estar en un arreglo");
      return;
    }

    let prestamosOK = [];
    let prestamosError = [];
    let totalPrestado = 0;

    prestamos.forEach(p => {

      if(p.monto <= 0){
        prestamosError.push({
          cliente: p.cliente,
          error: "Monto inválido"
        });
      }else{

        let interesTotal = p.monto * p.tasa * p.plazo;

        let totalPagar = p.monto + interesTotal;

        let cuotaMensual = totalPagar / p.plazo;

        totalPrestado += p.monto;

        prestamosOK.push({
          cliente: p.cliente,
          monto: p.monto,
          interesTotal: interesTotal,
          cuotaMensual: cuotaMensual
        });
      }

    });

    let reporte = {
      prestamosOK: prestamosOK,
      prestamosError: prestamosError,
      totalPrestado: totalPrestado
    };

    resolve(reporte);

  });
}

procesarPrestamos(prestamos)
.then(resultado => {
  console.log("Reporte final:", resultado);
})
.catch(error => {
  console.error(error);
});
