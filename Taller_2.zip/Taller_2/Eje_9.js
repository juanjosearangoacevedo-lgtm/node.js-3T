const reservas = [
  { cliente: "Ana", noches: 6, precioNoche: 100000 },
  { cliente: "Luis", noches: 2, precioNoche: 120000 }
];

function procesarReservas(reservas){
  return new Promise((resolve, reject) => {

    if(!Array.isArray(reservas)){
      reject("Error: las reservas deben estar en un arreglo");
      return;
    }

    let reservasProcesadas = [];
    let ingresosTotales = 0;

    reservas.forEach(r => {

      if(r.noches <= 0){
        reservasProcesadas.push({
          cliente: r.cliente,
          error: "Número de noches inválido"
        });
      }else{

        let subtotal = r.noches * r.precioNoche;

        let impuesto = subtotal * 0.10;

        let descuento = 0;

        if(r.noches > 5){
          descuento = subtotal * 0.15;
        }

        let total = subtotal + impuesto - descuento;

        ingresosTotales += total;

        reservasProcesadas.push({
          cliente: r.cliente,
          subtotal: subtotal,
          impuesto: impuesto,
          descuento: descuento,
          total: total
        });
      }

    });

    let reporte = {
      reservasProcesadas: reservasProcesadas,
      ingresosTotales: ingresosTotales
    };

    resolve(reporte);

  });
}


procesarReservas(reservas)
.then(resultado => {
  console.log("Reporte final:", resultado);
})
.catch(error => {
  console.error(error);
});
