const facturas = [
  { id: 1, productos: [{ precio: 20000, cantidad: 2 }, { precio: 10000, cantidad: 1 }] },
  { id: 2, productos: [] }
];

function procesarFacturas(facturas){
  return new Promise((resolve, reject) => {

    // Validación inicial
    if(!Array.isArray(facturas)){
      reject("Error: las facturas deben ser un arreglo");
      return;
    }

    let facturasOK = [];
    let facturasError = [];
    let totalFacturado = 0;

    facturas.forEach(factura => {

      // Validar que tenga productos
      if(!factura.productos || factura.productos.length === 0){
        facturasError.push({
          id: factura.id,
          error: "Factura sin productos"
        });
      }else{

        // Calcular subtotal
        let subtotal = 0;

        factura.productos.forEach(p => {
          subtotal += p.precio * p.cantidad;
        });

        // Calcular IVA
        let iva = subtotal * 0.19;

        // Calcular total
        let total = subtotal + iva;

        totalFacturado += total;

        facturasOK.push({
          id: factura.id,
          subtotal: subtotal,
          iva: iva,
          total: total
        });
      }

    });

    // Construir reporte final
    let reporte = {
      facturasOK: facturasOK,
      facturasError: facturasError,
      totalFacturado: totalFacturado
    };

    resolve(reporte);

  });
}

procesarFacturas(facturas)
.then(resultado => {
  console.log("Reporte final:", resultado);
})
.catch(error => {
  console.error(error);
});

