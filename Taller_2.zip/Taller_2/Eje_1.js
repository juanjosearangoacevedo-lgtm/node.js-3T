// Requerimientos
// 1.	Validar que salarioBase > 0
// 2.	Calcular valorHora = salarioBase / 240
// 3.	Calcular pagoHorasExtra (valorHora * 1.5 * horasExtra)
// 4.	Calcular salarioBruto
// 5.	Descuento salud = 4%
// 6.	Calcular salarioNeto
// 7.	Generar reporte:
// o	empleadosProcesados
// o	empleadosError
// o	totalNomina

const empleados = [
  { id: 1, nombre: "Ana", salarioBase: 2000000, horasExtra: 10 },
  { id: 2, nombre: "Luis", salarioBase: 1800000, horasExtra: 5 },
  { id: 3, nombre: "Carlos", salarioBase: 0, horasExtra: 8 }
];


function validaciones(listaEmpleados) {
    return new Promise((resolve, reject) => {
        if(listaEmpleados.salarioBase<0){
            return reject("Salario base inferior a 0")
        }
        if (!Array.isArray(listaEmpleados) || listaEmpleados.length === 0) {
            reject("No hay empleados para procesar");
            return;
        }
        let empleadosProcesados = [];
        let empleadosError = [];
        let totalNomina = 0;
    });
}
