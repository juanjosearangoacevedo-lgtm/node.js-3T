const usuarios = [
  { nombre: "Ana", consumo: 120, tarifa: 500 },
  { nombre: "Luis", consumo: 200, tarifa: 500 }
];


function procesarConsumoEnergia(usuarios){
  return new Promise((resolve, reject) => {

    if(!Array.isArray(usuarios)){
      reject("Error: los usuarios deben estar en un arreglo");
      return;
    }

    let listaFacturas = [];
    let totalRecaudado = 0;

    usuarios.forEach(u => {

      if(u.consumo <= 0){
        listaFacturas.push({
          nombre: u.nombre,
          error: "Consumo inválido"
        });
      }else{

        let costo = u.consumo * u.tarifa;

        let subsidio = 0;

        if(u.consumo < 150){
          subsidio = costo * 0.10;
        }

        let total = costo - subsidio;

        totalRecaudado += total;

        listaFacturas.push({
          nombre: u.nombre,
          consumo: u.consumo,
          costo: costo,
          subsidio: subsidio,
          total: total
        });
      }

    });

    let reporte = {
      listaFacturas: listaFacturas,
      totalRecaudado: totalRecaudado
    };

    resolve(reporte);

  });
}


procesarConsumoEnergia(usuarios)
.then(resultado => {
  console.log("Reporte final:", resultado);
})
.catch(error => {
  console.error(error);
});
