const estudiantes = [
  { nombre: "Ana", notas: [4.0, 3.5, 5.0] },
  { nombre: "Luis", notas: [] }
];


function procesarCalificaciones(estudiantes){
  return new Promise((resolve, reject) => {

    if(!Array.isArray(estudiantes)){
      reject("Error: los estudiantes deben estar en un arreglo");
      return;
    }

    let listaProcesada = [];
    let totalAprobados = 0;
    let totalReprobados = 0;

    estudiantes.forEach(est => {

      if(!est.notas || est.notas.length === 0){
        listaProcesada.push({
          nombre: est.nombre,
          error: "No tiene notas"
        });
      }else{

        let suma = 0;

        est.notas.forEach(n => {
          suma += n;
        });

        let promedio = suma / est.notas.length;

        let estado;

        if(promedio >= 3){
          estado = "Aprobado";
          totalAprobados++;
        }else{
          estado = "Reprobado";
          totalReprobados++;
        }

        listaProcesada.push({
          nombre: est.nombre,
          promedio: promedio,
          estado: estado
        });
      }

    });

    let reporte = {
      listaProcesada: listaProcesada,
      totalAprobados: totalAprobados,
      totalReprobados: totalReprobados
    };

    resolve(reporte);

  });
}


procesarCalificaciones(estudiantes)
.then(resultado => {
  console.log("Reporte final:", resultado);
})
.catch(error => {
  console.error(error);
});
