//1. ¿Qué es Node.js y para qué se utiliza?
//Node.js es una herramienta que permite usar JavaScript para crear la parte del servidor de una aplicación, es decir, lo que ocurre detrás de una página web como por ejemplo Netflix, Node.js guarda usuarios, inicia sesion, etc.
//se utiliza para crear APIS, conectar con base de datos, aplicaciones en tiempo real, Backend para aplicaciones como React.

//2. ¿Cuál es la diferencia entre JavaScript del navegador y JavaScript ejecutado con
//Node.js?
//En el navegador JavaScript esta dentro de una pestaña de internet (Chrome, Safari, Firefox). Está diseñado para que como usuarios, veamos cambios en la pantalla.
//En Node.js JavaScript vive directamente en el sistema operativo de la computadora (Windows, Mac, Linux). No necesita un navegador para funcionar.


//3. ¿Qué significa que Node.js sea asíncrono y no bloqueante?
//Node.js puede hacer varias tareas sin esperar a que una termine
//para continuar con la otra, es decir, funnciona enviando una orden
//y pasa a la otra sin esperar el resultado de la anterior, cuando el 
//resultado de la primera orden esta listo lo arroja.

//4.¿Para qué sirve require() en Node.js?
//Require() sirve para importar o cargar modulos como archivos o librerias dentro del programa.

//5.Explique la diferencia entre: var,let, const.
//las tres son formas para declarar variables, lo que diferencia a cada una es:
//var: era la que anteriomente se utilizaba en JavaScript.
//Let: se utiliza para variables que pueden cambiar su valor, pero esta no se puede volver a declarar con el mismo nombre en el mismo lugar.
//const: se utiliza para valores que no van a cambiar, es decir, es inmutable.

//6. ¿Qué es una promesa (Promise) en JavaScript?
//una promesa es un resultado que estara disponible en el futuro, este resultado puede fallar o ser exitoso.

////////////////////////////////////////////////////////////////////////////


//  function validar(a){
//     return new Promise((resolve, reject)=> {
//         setTimeout(()=> {
//             if(a>=60){
//                 resolve('Adulto mayor');
//             }else if (a>=18){
//                 resolve('Mayor de edad');

//             }else {
//                 resolve('Menor de edad');
//             }

//  validar(15)
//      .then(res => console.log(res))
//      .catch(err => console.log(err))


//  async function ejecutar() {

//      try{
//          const resultado = await validar (15);
//          console.log('Resultado', resultado);
        
//     }   catch (error) {
//          console.log (error);
//     }

// }

// ejecutar()

///////////////////////////////////////////////////////////////////////

// const saldo = 60000;
// saldo >= 50000 ?console.log('puede realizar la compra'): console.log('saldo insuficiente');


// const numeros = [2, 4, 6, 8, 10];

// numeros.forEach(function(numero) {
//   console.log(numero * 2);
// });

///////////////////////////////////////////////////////////////////////

// const productos = [
//   { nombre: "Arroz", precio: 3000, cantidad: 2 },
//   { nombre: "Leche", precio: 2500, cantidad: 3 }
// ];

// productos.forEach(producto => {
//   const total = producto.precio * producto.cantidad;

//   console.log("Producto:", producto.nombre);
//   console.log("Total:", total);
//   console.log("-------------");
// });


////////////////////////////////////////////////////////////////////

// function consultarUsuario() {
//   return new Promise((resolve, reject) => {

//     setTimeout(() => {
//       resolve({
//         id: 1,
//         nombre: "Carlos",
//         activo: true
//       });
//     }, 2000);

//   });
// }

// consultarUsuario()
//   .then(usuario => {
//     console.log("Usuario:", usuario);
//   })
//   .catch(error => {
//     console.log(error);
//   });

// async function mostrarUsuario() {
//   const usuario = await consultarUsuario();
//   console.log("Usuario:", usuario);
// }

// mostrarUsuario();


//////////////////////////////////////////////////////////

// function procesarPedido(pedido) {

//   return new Promise((resolve, reject) => {

//     if (pedido.cantidad > 0) {

//       const total = pedido.precio * pedido.cantidad;
//       resolve(total);

//     } else {

//       reject("Cantidad inválida");

//     }

//   });

// }

// procesarPedido({ producto: "Pan", precio: 2000, cantidad: 3 })
//   .then(total => {
//     console.log("Total del pedido:", total);
//   })
//   .catch(error => {
//     console.log(error);
//   });

// async function ejecutarPedido() {

//   try {
//     const total = await procesarPedido({
//       producto: "Pan",
//       precio: 2000,
//       cantidad: 3
//     });

//     console.log("Total del pedido:", total);

//   } catch (error) {

//     console.log(error);

//   }

// }

// ejecutarPedido();

/////////////////////////////////////////////////////////////////

// const pedidos = [
//   { producto: "Pan", precio: 2000, cantidad: 2 },
//   { producto: "Queso", precio: 5000, cantidad: 1 },
//   { producto: "Café", precio: 3000, cantidad: 4 }
// ];

// function calcularTotalPedidos() {

//   return new Promise((resolve) => {

//     let totalGeneral = 0;

//     pedidos.forEach(pedido => {
//       totalGeneral += pedido.precio * pedido.cantidad;
//     });

//     resolve(totalGeneral);

//   });

// }

// calcularTotalPedidos()
//   .then(total => {
//     console.log("Total general:", total);
//   });

// async function mostrarTotal() {

//   const total = await calcularTotalPedidos();
//   console.log("Total general:", total);

// }

// mostrarTotal();