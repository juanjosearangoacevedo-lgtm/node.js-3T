//Calcular promedio de notas
//Dado un arreglo de notas, calcular promedio asíncronamente.

const notas = [4.5, 3.8, 5.0, 4.2];


function calcularPromedio(notas) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (!Array.isArray(notas)) {
                reject("Error: el parámetro no es un arreglo");
                return;
            }

            if (notas.length === 0) {
                reject("Error: el arreglo está vacío");
                return;
            }

            const notasValidas = notas.every(nota => typeof nota === "number");

            if (!notasValidas) {
                reject("Error: todas las notas deben ser números");
                return;
            }

            const suma = notas.reduce((total, nota) => total + nota, 0);
            const promedio = suma / notas.length;

            resolve(promedio);
        }, 1000);
    });
}


async function ejecutarPromedio() {
    try {
        const resultado = await calcularPromedio(notas);
        console.log("Promedio:", resultado);
    } catch (error) {
        console.error(error);
    }
}

ejecutarPromedio();
