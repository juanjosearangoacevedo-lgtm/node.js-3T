// Simulación de login + mensaje
// Flujo:
// 1.	Validar usuario
// 2.	Si es correcto → mostrar “Bienvenido”


function validacion(usuario, contrasena) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (usuario !== "admin" || contrasena !== "1234") {
                reject("Login inválido");
            } else {
                resolve("Bienvenido");
            }
        }, 500);
    });
}

async function ejecutar() {
    try {
        const resultado = await validacion("admin", "1234");
        console.log("Resultado:", resultado);
    } catch (error) {
        console.log(error);
    }
}

ejecutar();
