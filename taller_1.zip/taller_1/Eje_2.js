// 2️⃣ Validación de edad
// Función validarEdad(edad):
// •	Si edad >= 18 → “Acceso permitido”
// •	Si no → rechazar con error


function filtrar(edad) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (typeof a !== "number") {
                return reject("Error: Números no válidos");
            }

            if (a<0) {
                return reject("No has nacido");
            }
            if (a>=18){
                return resolve("Accesoo permitido")
            }else return reject("Acceso NO permitido")
        }, 500);
    });
}

async function ejecutar() {
    try {
        const resultado = await operar(5, 5);
        console.log("Resultado:", resultado);
    } catch (error) {
        console.log(error);
    }
}

ejecutar();


