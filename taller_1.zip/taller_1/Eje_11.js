// Flujo de compra completo
// 1.	Validar usuario
// 2.	Validar stock
// 3.	Calcular total
// 4.	Confirmar compra

const usuario = {
  id: 1,
  nombre: "Juan",
  activo: true
};

const productos = [
  { nombre: "Camisa", precio: 50000, stock: 10, cantidad: 2 },
  { nombre: "Pantalón", precio: 80000, stock: 5, cantidad: 1 }
];


function validarUsuario(usuario) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (!usuario || !usuario.activo) {
        return reject(new Error("Usuario no válido o inactivo"));
      }
      resolve("Usuario validado");
    }, 1000);
  });
}

function validarStock(productos) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      for (const producto of productos) {
        if (producto.cantidad > producto.stock) {
          return reject(
            new Error(`Stock insuficiente para ${producto.nombre}`)
          );
        }
      }
      resolve("Stock validado");
    }, 1000);
  });
}

function calcularTotal(productos) {
  return new Promise((resolve) => {
    setTimeout(() => {
      let total = 0;

      for (const producto of productos) {
        total += producto.precio * producto.cantidad;
      }

      const iva = total * 0.19;
      const totalConIVA = total + iva;

      resolve({ total, iva, totalConIVA });
    }, 1000);
  });
}

function confirmarCompra(resumen) {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        mensaje: "Compra confirmada",
        resumen
      });
    }, 1000);
  });
}

// Ejecución del flujo
validarUsuario(usuario)
  .then(msg => {
    console.log(msg);
    return validarStock(productos);
  })
  .then(msg => {
    console.log(msg);
    return calcularTotal(productos);
  })
  .then(resumen => {
    console.log("Total:", resumen.total);
    console.log("IVA:", resumen.iva);
    console.log("Total con IVA:", resumen.totalConIVA);
    return confirmarCompra(resumen);
  })
  .then(resultado => {
    console.log(resultado.mensaje);
  })
  .catch(error => {
    console.error("Error en la compra:", error.message);
  });


async function flujoCompra(usuario, productos) {
  try {
    const msgUsuario = await validarUsuario(usuario);
    console.log(msgUsuario);

    const msgStock = await validarStock(productos);
    console.log(msgStock);

    const resumen = await calcularTotal(productos);
    console.log("Total:", resumen.total);
    console.log("IVA:", resumen.iva);
    console.log("Total con IVA:", resumen.totalConIVA);

    const confirmacion = await confirmarCompra(resumen);
    console.log(confirmacion.mensaje);

  } catch (error) {
    console.error("Error en la compra:", error.message);
  }
}

// Ejecutar
flujoCompra(usuario, productos);
