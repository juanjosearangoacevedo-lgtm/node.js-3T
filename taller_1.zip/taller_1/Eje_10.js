// Si cantidad solicitada > stock → error
// Si no → “Compra aprobada”


const productos = [
  { nombre: "Camisa", precio: 50000, stock: 10, cantidad: 3 },
  { nombre: "Pantalón", precio: 80000, stock: 5, cantidad: 6 }
];



function validarCompra(productos) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (!Array.isArray(productos) || productos.length === 0) {
        return reject(new Error("Lista de productos inválida"));
      }

      for (const producto of productos) {
        if (producto.cantidad > producto.stock) {
          return reject(
            new Error(`Stock insuficiente para ${producto.nombre}`)
          );
        }
      }

      resolve("Compra aprobada");
    }, 1500); // simulación asincrónica
  });
}

// Uso
validarCompra(productos)
  .then(mensaje => {
    console.log(mensaje);
  })
  .catch(error => {
    console.error("Error:", error.message);
  });
