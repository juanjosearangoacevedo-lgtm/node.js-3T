// Flujo de préstamo bancario
// 1.	Validar ingresos
// 2.	Validar historial crediticio
// 3.	Aprobar o rechazar préstamo

const cliente = {
  nombre: "Carlos",
  ingresosMensuales: 3000000, // COP
  historialCrediticio: "BUENO" // BUENO | REGULAR | MALO
};

const montoSolicitado = 8000000;


function validarIngresos(cliente, monto) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (cliente.ingresosMensuales < 2000000) {
        return reject(new Error("Ingresos insuficientes"));
      }

      if (monto > cliente.ingresosMensuales * 5) {
        return reject(new Error("Monto solicitado excede el límite permitido"));
      }

      resolve("Ingresos validados");
    }, 1000);
  });
}

function validarHistorial(cliente) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (cliente.historialCrediticio === "MALO") {
        return reject(new Error("Historial crediticio negativo"));
      }

      resolve("Historial crediticio validado");
    }, 1000);
  });
}

function aprobarPrestamo() {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve("Préstamo aprobado");
    }, 1000);
  });
}

// Ejecución
validarIngresos(cliente, montoSolicitado)
  .then(msg => {
    console.log(msg);
    return validarHistorial(cliente);
  })
  .then(msg => {
    console.log(msg);
    return aprobarPrestamo();
  })
  .then(resultado => {
    console.log(resultado);
  })
  .catch(error => {
    console.error("Préstamo rechazado:", error.message);
  });


async function flujoPrestamo(cliente, montoSolicitado) {
  try {
    const msgIngresos = await validarIngresos(cliente, montoSolicitado);
    console.log(msgIngresos);

    const msgHistorial = await validarHistorial(cliente);
    console.log(msgHistorial);

    const resultado = await aprobarPrestamo();
    console.log(resultado);

  } catch (error) {
    console.error("Préstamo rechazado:", error.message);
  }
}

// Ejecutar
flujoPrestamo(cliente, montoSolicitado);
