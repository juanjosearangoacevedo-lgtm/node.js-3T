// Validar usuario
// Simular validación de usuario:
// •	usuario: "admin"
// •	contraseña: "1234"


function validacion(usuario, contrasena) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (usuario !== "admin" || contrasena !== "1234") {
                reject("Login inválido");
            } else {
                resolve("Acceso concedido");
            }
        }, 500);
    });
}

async function ejecutar() {
    try {
        const resultado = await validacion("admin", "1234");
        console.log("Resultado:", resultado);
    } catch (error) {
        console.log(error);
    }
}

ejecutar();
