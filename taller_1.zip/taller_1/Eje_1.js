// // 1️⃣ Calculadora avanzada
// Crear función operar(a, b, tipo) que permita:
// •	suma
// •	resta
// •	multiplicación
// •	división (error si divide por 0)
// Debe devolver una promesa.


function operar(a, b) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (typeof a !== "number" || typeof b !== "number") {
                return reject("Error: Números no válidos");
            }

            if (b === 0) {
                return reject("Error: División por 0");
            }

            const resultado = {
                suma: a + b,
                resta: a - b,
                multi: a * b,
                divi: a / b
            };

            resolve(resultado);
        }, 500);
    });
}

async function ejecutar() {
    try {
        const resultado = await operar(5, 5);
        console.log("Resultado:", resultado);
    } catch (error) {
        console.log(error);
    }
}

ejecutar();


