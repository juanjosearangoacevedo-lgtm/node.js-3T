// Conversión de moneda
// Función convertirMoneda(valor, tasa)
// Debe devolver el valor convertido luego de 1 segundo.


function conversionMoneda(valor,tasa) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (typeof valor !== "number"|| typeof tasa !=="number") {
                return reject("Error: Números o tasa no válidos ");
            }else return resolve(valor*tasa)
        }, 500);
    });
}

async function ejecutar() {
    try {
        const resultado = await operar(5, 5);
        console.log("Resultado:", resultado);
    } catch (error) {
        console.log(error);
    }
}

ejecutar();


