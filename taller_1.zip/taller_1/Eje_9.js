//Generar factura
//Recibir arreglo de productos y calcular total + IVA.

const productos = [
  { nombre: "Camisa", precio: 50000 },
  { nombre: "Pantalón", precio: 80000 },
  { nombre: "Zapatos", precio: 120000 }
];


function calcularTotalConIVA(productos) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (!Array.isArray(productos) || productos.length === 0) {
        reject("El arreglo de productos no es válido");
        return;
      }

      let total = 0;

      for (let producto of productos) {
        if (typeof producto.precio !== "number") {
          reject("Precio inválido en uno de los productos");
          return;
        }
        total += producto.precio;
      }

      const iva = total * 0.19;
      const totalConIVA = total + iva;

      resolve({
        total,
        iva,
        totalConIVA
      });
    }, 2000); // simulación asincrónica
  });
}

// Uso
calcularTotalConIVA(productos)
  .then(resultado => {
    console.log("Total:", resultado.total);
    console.log("IVA:", resultado.iva);
    console.log("Total con IVA:", resultado.totalConIVA);
  })
  .catch(error => {
    console.error("Error:", error);
  });
