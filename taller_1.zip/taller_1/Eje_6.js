//  Filtrar productos por precio
// Dado un arreglo de productos, devolver solo los mayores a cierto precio.

const productos =[
    {nombre:"Play 5", precio:1300000},
    {nombre:"Series S", precio:1600000},
    {nombre:"Play 4", precio:500000},
    {nombre:"Nintendo", precio:2000000},
]

function filtrarProductos() {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
        if (!Array.isArray(productos)) {
            reject("Error: productos no es un arreglo");
            return;
        }
        if(typeof precioMinimo !== "number"){
            reject("Precio invalido")
        }

        const filtrados= productos.filter(
            producto => producto.precio>precioMinimo 
        )
        if (filtrados.length === 0) {
                reject("No hay productos mayores a ese precio");
            } else {
                resolve(filtrados);
            }
        }, 1000);
    });
}

async function ejecutarFiltro() {
    try {
        const resultado = await filtrarProductos(productos, 200);
        console.log("Productos filtrados:", resultado);
    } catch (error) {
        console.error(error);
    }
}

ejecutarFiltro();
