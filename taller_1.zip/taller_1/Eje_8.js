// Buscar usuario por ID
// Simular base de datos:

function buscarUsuarioPorId(id) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (typeof id !== "number") {
                reject("Error: el ID debe ser un número");
                return;
            }

            const usuario = usuarios.find(u => u.id === id);

            if (usuario) {
                resolve(usuario);
            } else {
                reject("Usuario no encontrado");
            }
        }, 1000);
    });
}

// Uso con then / catch
buscarUsuarioPorId(2)
    .then(usuario => {
        console.log("Usuario encontrado:", usuario);
    })
    .catch(error => {
        console.error(error);
    });



async function ejecutarBusqueda() {
    try {
        const resultado = await buscarUsuarioPorId(1);
        console.log("Usuario encontrado:", resultado);
    } catch (error) {
        console.error(error);
    }
}

ejecutarBusqueda();
